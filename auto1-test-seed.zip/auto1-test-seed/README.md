# To start

`yarn` or `npm install`
`yarn start` or `npm start`
